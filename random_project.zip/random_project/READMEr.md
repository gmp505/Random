# random Bibliotēkas Analīze

**Projekts:** Python bibliotēkas izpēte  
**Bibliotēka:** random (Pseudo-random number generator)  
**Autors:** Gvido Mārtiņš Puķītis
**Klase:** 11.b
  



## Kapēc izvēlējos šo bibliotēku.

Es izvēlējos random, Python iebūvēto nejaušo skaitļu ģenerēšanas bibliotēku, vairāku iemeslu dēļ. Pirmkārt, random ir viena no visbiežāk izmantotajām Python bibliotēkām, jo tā ir pieejama katrā Python instalācijā bez papildu uzstādīšanas. To izmanto spēļu izstrādē, statistikas simulācijās, datu zinātnē un testu automatizācijā. Otrkārt, random risina būtisku programmēšanas problēmu, nodrošinot nedeterministisku uzvedību. Bez nejaušajiem skaitļiem nebūtu iespējams izveidot spēles, simulācijas, drošas paroles vai objektīvus datu paraugus. Treškārt, bibliotēka piedāvā dažādu sarežģītības pakāpju funkcijas, sākot no vienkāršas veselu skaitļu ģenerēšanas līdz statistiskajiem sadalījumiem, piemēram, Gausa, beta un eksponenciālajam sadalījumam, tāpēc tā ir noderīga gan iesācējiem, gan pieredzējušiem programmētājiem.


## Bibliotēkas funkciju apraksti

*random.seed()
Iestata sākumvērtību jeb seed. Vienāds seed nodrošina reproducējamus rezultātus.
*random.random()
Atgriež nejaušu decimālskaitli intervālā [0.0, 1.0). Tā ir pamata nejaušo skaitļu ģenerēšanas funkcija.
*random.randint(a, b)
Atgriež nejaušu veselu skaitli no a līdz b, ieskaitot abas robežas.
*random.uniform(a, b)
Atgriež nejaušu decimālskaitli no a līdz b.
*random.randrange(start, stop, step)
Atgriež nejaušu veselu skaitli no diapazona ar norādītu soli. Darbojas līdzīgi range().
*random.choice(seq)
Atgriež vienu nejauši izvēlētu elementu no secības, piemēram, saraksta vai virknes.
*random.choices(seq, k=n)
Atgriež n elementus ar atkārtošanos. Atbalsta arī svērtās varbūtības.
*random.sample(seq, k)
Atgriež k unikālus elementus bez atkārtošanās. Bieži izmanto loterijās un nejaušās atlasēs.
*random.shuffle(lst)
Samaisa saraksta elementus uz vietas, mainot oriģinālo sarakstu.
*random.gauss(mu, sigma)
Ģenerē nejaušu skaitli pēc Gausa jeb normālā sadalījuma.
*random.normalvariate(mu, sigma)
Ģenerē nejaušu skaitli pēc normālā sadalījuma. Līdzīga funkcija kā gauss().
*random.triangular(low, high, mode)
Ģenerē skaitli pēc trīsstūra sadalījuma ar norādītu visiespējamāko vērtību.
*random.expovariate(lambd)
Ģenerē skaitli pēc eksponenciālā sadalījuma. Izmanto gaidīšanas laiku modelēšanai.
*random.betavariate(alpha, beta)
Ģenerē skaitli pēc beta sadalījuma intervālā [0,1]. Izmanto varbūtību modelēšanā.
*random.getrandbits(k)
Ģenerē nejaušu k bitu veselu skaitli. Var izmantot tokenu vai zema līmeņa nejaušo datu ģenerēšanai.

---

## Projekta struktūra

```
random_project/
│
├── README.md               <- šis fails
├── cheat_sheet.py          <- visas 15 funkcijas vienā failā
├── main.py                 <- interaktīva demonstrācijas programma
│
└── functions/              <- katras funkcijas atsevišķs .py fails
    ├── 01_seed.py
    ├── 02_random.py
    ├── 03_randint.py
    ├── 04_uniform.py
    ├── 05_randrange.py
    ├── 06_choice.py
    ├── 07_choices.py
    ├── 08_sample.py
    ├── 09_shuffle.py
    ├── 10_gauss.py
    ├── 11_normalvariate.py
    ├── 12_triangular.py
    ├── 13_expovariate.py
    ├── 14_betavariate.py
    └── 15_getrandbits.py
```

---

## Kā palaist

**Nav nepieciešama uzstādīšana** — `random` ir iebūvēta Python bibliotēka.

```bash
python cheat_sheet.py
python main.py
python functions/03_randint.py
```

---
### Secinājumi par bibliotēkas ieguvumiem un ierobežojumiem


*Ieguvumi


random ir iebūvēta Python standarta bibliotēkā, tāpēc nav nepieciešama papildu instalēšana un to var izmantot uzreiz jebkurā Python vidē.

Bibliotēka piedāvā plašu funkciju klāstu, sākot no vienkāršām darbībām, piemēram, randint() un choice(), līdz statistiskajiem sadalījumiem, piemēram, Gausa un beta sadalījumam.

random.seed() ļauj reproducēt rezultātus, kas ir īpaši svarīgi testēšanā, simulācijās un zinātniskos eksperimentos.


*Ierobežojumi


random nav kriptogrāfiski droša bibliotēka, tāpēc to nevajadzētu izmantot paroļu, tokenu vai drošības atslēgu ģenerēšanai.

Bibliotēka ģenerē pseidonejaušus skaitļus, kas nozīmē, ka rezultātus teorētiski var paredzēt, ja zināms sākotnējais seed.

Sarežģītākai statistiskai analīzei un plašākam sadalījumu klāstam piemērotākas ir bibliotēkas numpy.random un scipy.stats.

---

## Avoti

- Python dokumentācija: https://docs.python.org/3/library/random.html
- Mersenne Twister: https://en.wikipedia.org/wiki/Mersenne_Twister
- Python secrets modulis (kriptogrāfijai): https://docs.python.org/3/library/secrets.html
